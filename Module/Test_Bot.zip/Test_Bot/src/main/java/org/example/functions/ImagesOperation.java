package org.example.functions;

public interface ImagesOperation {
    float[] execute(float[] rgb);
}
