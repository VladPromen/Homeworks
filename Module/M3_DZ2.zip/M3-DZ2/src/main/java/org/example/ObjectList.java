package org.example;

public class ObjectList<E> {
    private final E object;
    ObjectList<E> place;
    public ObjectList(E object){
        this.object = object;
    }
    public E getObject() {
        return object;
    }
}
