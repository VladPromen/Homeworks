package org.example;

public class Main {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.insert(1);
        myLinkedList.insert(2);
        myLinkedList.insert(3);
        myLinkedList.insert(4);
        myLinkedList.delete(1);
        myLinkedList.delete(4);
        myLinkedList.insert(35);
        myLinkedList.insert(45);
        myLinkedList.delete(3);
        myLinkedList.delete(4);
        System.out.println(myLinkedList.find(3));
        System.out.println(myLinkedList.size);
    }
}