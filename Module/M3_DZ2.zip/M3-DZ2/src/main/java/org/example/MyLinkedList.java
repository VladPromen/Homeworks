package org.example;

public class MyLinkedList<E> {
    ObjectList<E> first;
    Integer size = 0;

    public MyLinkedList() {
        first = null;
    }

    public void insert(E object) {
        ObjectList<E> newObjectList = new ObjectList<>(object);
        if (first == null) {
            first = newObjectList;
        } else {
            ObjectList<E> el = first;
            while (el.place != null) {
                el = el.place;
            }
            el.place = newObjectList;
        }
        size++;
    }

    private ObjectList<E> f(E element) {
        ObjectList<E> el = first;
        while (el.getObject() != element) {
            if (el.getObject() == null) {
                return null;
            }
            el = el.place;
            if (el == null) {
                break;
            }
        }
        return el;
    }
    public boolean find(E element){
        return f(element) != null;
    }
    public void delete(Object object) {
        ObjectList<E> element = f((E) object);
        if (element != null) {
            ObjectList<E> el = first;
            ObjectList<E> elel = first;
            while (el != element && el != null) {
                elel = el;
                el = el.place;
            }
            if (el == first) {
                assert first != null;
                first = first.place;
                size--;
            } else if (el != null) {
                elel.place = el.place;
                size--;
            }
        }
    }
}
