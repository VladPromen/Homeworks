package org.example;

public class Plastic {
}
