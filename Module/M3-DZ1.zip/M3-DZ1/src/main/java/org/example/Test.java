package org.example;

public class Test {
    public static void main(String[] args) {
        Object metal = new Steel();
        Sword n = new Sword((Metal) metal);
        System.out.println(n.test(n));
        metal = new Copper();
        Sword nn = new Sword((Metal) metal);
        System.out.println(n.test(nn));
        metal = new Iron();
        Sword nnn = new Sword((Metal) metal);
        System.out.println(n.test(nnn));
        metal = new Plastic();
        Sword nnnn = null;
        try {
            nnnn = new Sword((Metal) metal);
            System.out.println(n.test(nnnn));
        } catch (Exception e) {
            System.out.println("ERROR");
        }
    }
}
