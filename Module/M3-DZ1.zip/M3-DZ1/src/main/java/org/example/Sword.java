package org.example;

public class Sword{
    Metal material;
    public Sword(Metal metal){
        material = metal;
    }
    public boolean test(Sword e){
    if (49<e.material.getEndurance()){
        return true;
    }else {
        return false;
    }
    }
}
