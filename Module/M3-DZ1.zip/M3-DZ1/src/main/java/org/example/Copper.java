package org.example;

public class Copper extends Metal{
    @Override
    public int getEndurance() {
        return 20;
    }
}
