package org.example;

public class Iron extends Metal{
    @Override
    public int getEndurance() {
        return 30;
    }
}
