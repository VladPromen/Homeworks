package org.example;

public abstract class Metal {
    public abstract int getEndurance();
}
