package org.example;

public class Main {
    public static void main(String[] args) {
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();
        myLinkedList.insert(1);
        myLinkedList.insert(2);
        myLinkedList.insert(3);
        myLinkedList.insert(4);
        myLinkedList.delete(myLinkedList.find(1));
        myLinkedList.delete(myLinkedList.find(4));
        System.out.println(myLinkedList.find(3).getObject());
        System.out.println(myLinkedList.size);
    }
}