package org.example;

public class MyLinkedList<E> {
    ObjectList<E> first;
    Integer size = 0;

    public MyLinkedList(){
        first = null;
    }

    public void insert(E object){
        ObjectList<E> newObjectList = new ObjectList<>(object);
        newObjectList.place = first;
        first = newObjectList;
        size++;
    }
    public ObjectList<E> find(E element) {
        ObjectList<E> el = first;
        while (el.getObject() != element) {
            if (el.getObject() == null) {
                return null;
            }
            el = el.place;
        }
        return el;
    }
    public void delete(ObjectList<E> element){
        ObjectList<E> el = first;
        ObjectList<E> elel = first;
        while (el.getObject() == element){
            if (el.getObject() == null){
                return;
            }
            elel = el;
            el = el.place;
        }
        if (el.getObject() == first){
            first = first.place;
        }else {
            elel.place = el.place;
        }
        size--;
    }
}
