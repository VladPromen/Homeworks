package org.example;

public class MyTreeSet<E> {
    MyTreeMap<E, E> map;

    public MyTreeSet(){
        map = new MyTreeMap<>();
    }
    public boolean add(E object){
        if (contains(object)){
            return false;
        } else {
            map.put(object, object);
            return true;
        }
    }
    public void remove(E object){
        map.remove(object);
    }
    public boolean contains(E object){
        return map.get(object) != null;
    }
}
