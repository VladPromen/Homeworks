package org.example;

public class Counter {
    private int count;
    void increment(){
        synchronized (this) {
            count++;
        }
    }
    public int getValue() {
        return count;
    }
}
