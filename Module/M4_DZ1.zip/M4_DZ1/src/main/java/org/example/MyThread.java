package org.example;
public class MyThread extends Thread {
    Counter j;
    public void run(){
        Counter j = new Counter();
        for (int i = 0; i != 1000; i++) {
            j.increment();
        }
        System.out.println(j.getValue());
    }
}
