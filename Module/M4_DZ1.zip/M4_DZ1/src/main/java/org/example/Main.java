package org.example;

public class Main {
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        MyThread Thread = new MyThread();
        myThread.start();
        Thread.start();
    }
}