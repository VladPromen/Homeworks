package com.example.m4_dz5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;
import java.util.Scanner;

public class TestResources extends AppCompatActivity {

    private boolean isSubscribed = false;

    private Button colorChangeButton;

    private View mainLoyalt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_resources);

        String profilename = "Slava";
        setTitle("Профиль пользователя " + profilename);

        Button buttonSub = findViewById(R.id.buttonSubscribe);

        buttonSub.setOnClickListener(view -> {

            if (isSubscribed) {
                Snackbar snackbar = Snackbar.make(view, "Вы точно хотите отписаться от " + profilename +"?", Snackbar.LENGTH_SHORT)
                        .setAction("Да, отписаться", v ->{
                            buttonSub.setBackgroundColor(getResources().getColor(R.color.notSubscribe_button_color));
                            buttonSub.setText("Подписаться");
                        });
                snackbar.show();
                if (buttonSub.getText()!="Подписаться"){
                    isSubscribed = !isSubscribed;
                }
            } else {
                buttonSub.setBackgroundColor(getResources().getColor(R.color.Subscribe_button_color));
                buttonSub.setText("Отписаться");

                Toast toast = Toast.makeText(getApplicationContext(), "Вы подписались на" + profilename, Toast.LENGTH_LONG);
                toast.show();
                isSubscribed = !isSubscribed;
            }
        });

        colorChangeButton = findViewById(R.id.changeColorButton);
        mainLoyalt = findViewById(R.id.main_layout);

        colorChangeButton.setOnClickListener(v -> changeBackgrounfColor());
    }

    private void changeBackgrounfColor(){
        Random random = new Random();
        int color = android.graphics.Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
        mainLoyalt.setBackgroundColor(color);
    }
}