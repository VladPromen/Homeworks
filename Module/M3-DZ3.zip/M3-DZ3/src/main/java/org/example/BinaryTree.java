package org.example;

public class BinaryTree {
    Node root;
    Integer size = 0;
    private Node addRecursive(Node current, int data){
        if (current == null){
            return new Node(data);
        }
        if (data < current.data){
            current.left = addRecursive(current.left, data);
        } else if (data > current.data){
            current.right = addRecursive(current.right, data);
        } else {
            return current;
        }
        return current;
    }
    public void add(int value){
        root = addRecursive(root, value);
        size++;
    }
    private boolean containsNodeRecursive(Node current, int data){
        if (current == null){
            return false;
        }
        if (current.data == data){
            return true;
        }
        return data < current.data
                ? containsNodeRecursive(current.left, data)
                : containsNodeRecursive(current.right, data);
    }
    public boolean containsNode(int value){
        return containsNodeRecursive(root, value);
    }
    private void deleteRecursive(Node current, int data){
        Node lastcurrent = null;
        int i = 1;

        while (current.data != data) {
            if (current.data > data) {
                lastcurrent = current;
                current = current.left;
            } else {
                lastcurrent = current;
                current = current.right;
            }
            i++;
        }

        if (current.left == null && current.right == null) {
            if (i == 1){
                current = null;
            }
            if (lastcurrent.left == current) {
                lastcurrent.left = null;
            } else {
                lastcurrent.right = null;
            }
        }

        else if ((current.left == null && current.right != null) || (current.left != null && current.right == null)){
            if (i == 1){
                if (current.left != null){
                    root = current.left;
                } else {
                    root = current.right;
                }
            } else if (lastcurrent.left == current) {
                if (current.left != null){
                    lastcurrent.left = current.left;
                } else {
                    lastcurrent.left = current.right;
                }
            } else {
                    if (current.left != null){
                        lastcurrent.right = current.left;
                    } else {
                        lastcurrent.right = current.right;
                    }
                }
            }

        else {
            while (current.left != null && current.right != null) {
                while (current.left != null) {
                    current.data = current.left.data;
                    lastcurrent = current;
                    current = current.left;
                }
                if (current.right != null) {
                    lastcurrent = current;
                    current = current.right;
                }
            }
            if (lastcurrent.left == current){
                lastcurrent.left = null;
            } else {
                lastcurrent.right = null;
            }
        }
        size--;
    }
    public void delete(int value){
        deleteRecursive(root, value);
    }
}
