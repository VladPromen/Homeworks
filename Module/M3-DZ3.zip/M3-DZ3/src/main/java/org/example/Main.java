package org.example;

public class Main {
    public static void main(String[] args) {
        BinaryTree binaryTree = new BinaryTree();
        binaryTree.add(100);
        binaryTree.add(50);
        binaryTree.add(25);
        binaryTree.add(30);
        binaryTree.add(27);
        binaryTree.add(20);
        binaryTree.delete(30);
        System.out.println(binaryTree.containsNode(50));
        System.out.println(binaryTree.containsNode(30));
        System.out.println(binaryTree.containsNode(27));
        System.out.println(binaryTree.containsNode(100));
        System.out.println(binaryTree.containsNode(25));
        System.out.println(binaryTree.containsNode(20));
        System.out.println(binaryTree.size);
    }
}