package org.example;

import java.util.TreeMap;

public class MyTreeSet<E> {
    TreeMap<E, E> map;

    public MyTreeSet(){
        map = new TreeMap<>();
    }
    public boolean add(E object){
        if (contains(object)){
            return false;
        } else {
            map.put(object, object);
            return true;
        }
    }
    public void remove(E object){
        map.remove(object);
    }
    public boolean contains(E object){
        if (map.get(object) == null){
            return false;
        } else {
            return true;
        }
    }
}
