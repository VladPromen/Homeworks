package org.example;

public class MyTreeSet2<E> {
    MyTreeMap<E, E> map;

    public MyTreeSet2(){
        map = new MyTreeMap<>();
    }
    public boolean add(E object){
        if (contains(object)){
            return false;
        } else {
            map.put(object, object);
            return true;
        }
    }
    public void remove(E object){
        map.remove(object);
    }
    public boolean contains(E object){
        if (map.get(object) == null){
            return false;
        } else {
            return true;
        }
    }
}
