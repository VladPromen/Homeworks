package org.example;

public class MyTreeMap<K, V>{
    class Node{
        public K key;
        public V value;

        Node left;
        Node right;

        Node(K key, V value){
            this.key = key;
            this.value = value;
        }
    }

    private int size;
    private Node root;

    MyTreeMap(){
        root = null;
    }

    public int size(){
        return size;
    }

    public boolean isEmpty(){
        return size == 0;
    }

    public void clear(){
        size = 0;
        root = null;
    }

    public V get(K key){
        Node node = findNode(key);
        if (node == null){
           return null;
        } else {
            return node.value;
        }
    }

    public V remove(K key){
        V value = get(key);
        root = del(key);
        return value;
    }

    public V put(K key, V value){
        if (key == null){
            throw new NullPointerException();
        }
        if (root == null){
            root = new Node(key, value);
            size++;
            return value;
        }
        return PutHelper(root, key, value);
    }

    private V PutHelper(Node node, K key, V value) {
        Comparable<? super K> k = (Comparable<? super K>) key;
        int cpm = k.compareTo(node.key);
        if (cpm < 0) {
            if (node.left == null) {
                node.left = new Node(key, value);
                size++;
                return node.left.value;
            } else {
                return PutHelper(node.left, key, value);
            }
        }
        if (cpm > 0) {
            if (node.right == null) {
                node.right = new Node(key, value);
                size++;
                return node.right.value;
            } else {
                return PutHelper(node.right, key, value);
            }
        }
        node.value = value;
        return value;
    }
    private Node findNode(K key){
        if (key == null){
            throw new NullPointerException();
        }

        Comparable<? super K> k = (Comparable<? super K>) key;

        Node node = root;
        while (node != null){
            int cpm = k.compareTo(node.key);
            if (cpm < 0){
                node = node.left;
            } else if (cpm > 0){
                node = node.right;
            } else {
                return node;
            }
        }
        return null;
    }
    private Node del(K key){
        Node node = findNode(key);
        if (node.left == null && node.right == null){
            node = null;
            size--;
            return node;
        }
        if (node.right == null){
            node = node.left;
            size--;
            return node;
        }
        if (node.left == null){
            node = node.right;
            size--;
            return node;
        }
        node = findSmallestValue(node.right);
        size--;
        return node;
    }
    private Node findSmallestValue(Node root){
        return root.left == null ? root : findSmallestValue(root.left);
    }
}
