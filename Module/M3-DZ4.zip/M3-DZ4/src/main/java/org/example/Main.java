package org.example;

public class Main {
    public static void main(String[] args) {
        MyTreeSet<Integer> myTreeSet = new MyTreeSet*-<>();
        myTreeSet.add(1);
        myTreeSet.add(2);
        myTreeSet.add(3);
        myTreeSet.add(4);
        myTreeSet.add(5);
        myTreeSet.remove(2);
        myTreeSet.remove(4);
        System.out.println(myTreeSet.contains(1));
        System.out.println(myTreeSet.contains(2));
        System.out.println(myTreeSet.contains(3));
        System.out.println(myTreeSet.contains(4));
        System.out.println(myTreeSet.contains(5));
    }
}