package org.example;
import java.util.HashMap;

public class MyHashSet<E>{
    private final MyHashMap<E, E> map;
    public Integer size = 0;
    public MyHashSet() {
        this.map = new MyHashMap<>();
    }
    public boolean add(E object){
        if (map.contains(object)){
            return false;
        } else {
            map.put(object, object);
            size++;
            return true;
        }
    }
    public boolean remove(E object){
        if (map.contains(object)){
            size--;
            map.remove(object);
            return true;
        }
        return false;
    }
    public boolean contains(E object){
        return map.contains(object);
    }
}

