package com.example.m4_dz4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityD extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d);
    }
}