package org.example;
import java.util.HashMap;
public class MyHashSet<E>{
    private final HashMap<E, E> map;
    public Integer size = 0;
    public MyHashSet() {
        this.map = new HashMap<>();
    }
    public HashMap<E, E> getMap() {
        return map;
    }
    public boolean add(E object){
        if (map.containsKey(object)){
           return false;
        } else {
            map.put(object, object);
            size++;
            return true;
        }
    }
    public boolean remove(E object){
        if (map.containsKey(object)){
            size--;
        }
        return map.remove(object, object);
    }
    public boolean contains(E object){
        return map.containsKey(object);
    }
}
