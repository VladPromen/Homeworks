package org.example;

public class Main {
    public static void main(String[] args) {
        MyHashSet<Integer> myHashSet = new MyHashSet<>();
        myHashSet.add(2);
        System.out.println(myHashSet.add(1));
        System.out.println(myHashSet.add(1));
        System.out.println(myHashSet.size);
        System.out.println(myHashSet.contains(2));
        System.out.println(myHashSet.contains(1));
        System.out.println(myHashSet.getMap());
        System.out.println(myHashSet.remove(1));
        System.out.println(myHashSet.size);
        System.out.println(myHashSet.getMap());
        System.out.println(myHashSet.contains(2));
        System.out.println(myHashSet.contains(1));
    }
}