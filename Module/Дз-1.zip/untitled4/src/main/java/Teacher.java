import java.util.Scanner;
import java.util.function.Function;

public class Teacher {
    Student[] hArray = new Student[3];
    String name2;
    int age2;

    Scanner scanner = new Scanner(System.in);

    Teacher() {
        for (int i = 0; i < 3; i++) {
            hArray[i] = new Student();
            age2 = 43;
            name2 = "Oleg";
        }
    }
    void function() {
        System.out.println("Выберите: 1)День рождения 2)Переход на новый курс 3)Вывод информации 4)О преподавателе");
        int x;
        x = scanner.nextInt();
        if (x == 1) {
            int s;
            System.out.println("Выберите ученика 0-2");
            s = scanner.nextInt();
            hArray[s].birthday();
        }
        if (x == 2) {
            int s;
            System.out.println("Выберите ученика 0-2");
            s = scanner.nextInt();
            hArray[s].newcurs();
        }
        if (x == 3) {
            int s;
            System.out.println("Выберите ученика 0-2");
            s = scanner.nextInt();
            hArray[s].info();
        }
        if (x == 4) {
            System.out.println("Имя-" + name2 + " -Возраст-" + age2);
        }
    }
}
