import java.util.Scanner;

public class University {
    public static void main(String[] args) {
        Teacher[] jArray = new Teacher[3];

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            jArray[i] = new Teacher();
        }
        System.out.println("3 преподавателя наняты");
        for (int a = 1; a != 0;) {
            int r;
            System.out.println("Выберите преподавателя 0-2");
            r = scanner.nextInt();
            jArray[r].function();
        }
    }
}
