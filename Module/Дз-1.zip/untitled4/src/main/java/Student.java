public class Student {
    int age;
    String name;
    private int curs;

    int birthday () {
        age++;
        System.out.println("С днём рождения " + name + "!");
        return age;
    }
    int newcurs () {
        curs++;
            System.out.println("С переходом на " + curs + " курс!");
            return curs;
    }
        void setcurs(int newcurs) {
            if (newcurs > 0 && newcurs < 5) {
                this.curs = newcurs;
            }
        }
        int getcurs() {
            return this.curs;
        }
    Student() {
        age = 18;
        name = "Mike";
        curs = 1;
    }
    void info(){
        System.out.println("Имя-" + name + " Возраст-" + age + " Курс-" + curs);
    }
}

